<!DOCTYPE html>
<html class="x-admin-sm">
  
  <head>
    <meta charset="UTF-8">
    <title>欢迎页面-X-admin2.2</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width,user-scalable=yes, minimum-scale=0.4, initial-scale=0.8,target-densitydpi=low-dpi" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="/css/font.css">
    <link rel="stylesheet" href="/css/xadmin.css">
    <script type="text/javascript" src="/lib/layui/layui.js" charset="utf-8"></script>
    <script type="text/javascript" src="/js/xadmin.js"></script>
    <style>
        /*表格内容居中*/
        .layui-table th,tr{
                text-align: center;
            }
        .layui-input{
            width: 120px;border: none;margin: auto;text-align: center;
        }
    </style>
  </head>
  
  <body>
    <div class="layui-fluid">
        <div class="layui-row">
            <form class="layui-form layui-form-pane">
                <input type="hidden" name="product_id" value="<?php echo e($product->product_id); ?>">
                <div class="layui-form-item">
                    <?php if(isset($product)): ?>
                    <label for="name" class="layui-form-label">
                        保险公司
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" required="" lay-verify="required" value="<?php echo e($product->insurance_company_name); ?>"
                        autocomplete="off" class="layui-input" style="width: 190px;" readonly>
                    </div>
                    <?php else: ?>
                    <label for="name" class="layui-form-label">
                        保险公司
                    </label>
                    <div class="layui-input-inline">
                        <select class="valid" lay-verify="required" lay-search>
                            <option value="">请选择</option>
                            <?php $__currentLoopData = $insuranceCompanys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insuranceCompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($insuranceCompany->insurance_company_id); ?>"><?php echo e($insuranceCompany->insurance_company_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <label for="name" class="layui-form-label">
                        产品名称
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" required="" lay-verify="required" value="<?php echo e($product->insurance_company_name); ?>"
                        autocomplete="off" class="layui-input" style="width: 190px;" readonly>
                    </div>
                    <label for="name" class="layui-form-label">
                        产品类型
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" required="" lay-verify="required" value="<?php echo e($product->insurance_company_name); ?>"
                        autocomplete="off" class="layui-input" style="width: 190px;" readonly>
                    </div>
                    <label for="name" class="layui-form-label">
                        产品状态
                    </label>
                    <div class="layui-input-inline">
                        <input type="text" required="" lay-verify="required" value="<?php echo e($product->insurance_company_name); ?>"
                        autocomplete="off" class="layui-input" style="width: 190px;" readonly>
                    </div>
                </div>
                <div class="layui-form-item layui-form-text">
                    <table  class="layui-table layui-input-block">
                        <thead>
                            <tr>
                                <!-- <th>产品名称</th> -->
                                <th>佣金率</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <!-- <td style="text-align: center;">
                                    <?php echo e($product->product_name); ?>

                                </td> -->
                                <td>
                                    <div class="layui-input-block">
                                        <table  class="layui-table">
                                            <thead>
                                                <tr>
                                                    <th>缴费期间（年）</th>
                                                    <th>首佣（%）</th>
                                                    <th>第二年（%）</th>
                                                    <th>第三年（%）</th>
                                                    <th>第四年（%）</th>
                                                    <th>第五年（%）</th>
                                                </tr>
                                            </thead>
                                            
                                            <tbody id="demo">
                                                <?php if($commissions->isEmpty()): ?>
                                                <tr>
                                                    <td>
                                                        <input type="text" name="new_payment_period" class="layui-input" value="">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="new_first_year_rate" class="layui-input" value="">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="new_second_year_rate" class="layui-input" value="">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="new_third_year_rate" class="layui-input" value="">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="new_fourth_year_rate" class="layui-input" value="">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="new_fifth_year_rate" class="layui-input" value="">
                                                    </td>
                                                </tr>
                                                <?php else: ?>
                                                <?php $__currentLoopData = $commissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <input type="text" name="<?php echo e($commission->commission_id); ?>_payment_period" class="layui-input" value="<?php echo e($commission->payment_period); ?>">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="<?php echo e($commission->commission_id); ?>_first_year_rate" class="layui-input" value="<?php echo e($commission->first_year_rate); ?>">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="<?php echo e($commission->commission_id); ?>_second_year_rate" class="layui-input" value="<?php echo e($commission->second_year_rate); ?>">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="<?php echo e($commission->commission_id); ?>_third_year_rate" class="layui-input" value="<?php echo e($commission->third_year_rate); ?>">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="<?php echo e($commission->commission_id); ?>_fourth_year_rate" class="layui-input" value="<?php echo e($commission->fourth_year_rate); ?>">
                                                    </td>
                                                    <td>
                                                        <input type="text" name="<?php echo e($commission->commission_id); ?>_fifth_year_rate" class="layui-input" value="<?php echo e($commission->fifth_year_rate); ?>">
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                            </tbody>

                                        </table>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <?php if($commissions->isEmpty()): ?>
                    <button type="button" class="layui-btn" onclick="addTable()">新增一行</button>
                    <?php endif; ?>
                </div>
                
                <div class="layui-form-item" style="text-align: center;">
                    <button class="layui-btn" style="width: 100px;" lay-submit="" lay-filter="add">保&emsp;存</button>
              </div>
            </form>
        </div>
    </div>
    <script>
        layui.use(['form','layer'], function(){
            $ = layui.jquery;
          var form = layui.form
          ,layer = layui.layer;
        
          //自定义验证规则
          form.verify({
            nikename: function(value){
              if(value.length < 5){
                return '昵称至少得5个字符啊';
              }
            }
            ,pass: [/(.+){6,12}$/, '密码必须6到12位']
            ,repass: function(value){
                if($('#L_pass').val()!=$('#L_repass').val()){
                    return '两次密码不一致';
                }
            }
          });

        

          //监听提交
          form.on('submit(add)', function(data){
            //发异步，把数据提交给php
            $.ajax({
                url:  '/product/list/<?php echo e($product->product_id); ?>/commission/save',
                data: data.field,
                headers:{
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: 'POST',
                dataType: 'json',
                success:function(data) {
                    layer.msg(data.message, {icon: 6,time:500},function () {
                        // 获得frame索引
                        var index = parent.layer.getFrameIndex(window.name);
                        //关闭当前frame
                        parent.layer.close(index);
                    });
                },
                error:function(data){
                    layer.msg('服务器连接失败');
                }
            });
            return false;
          });


            form.on('checkbox(father)', function(data){

                if(data.elem.checked){
                    $(data.elem).parent().siblings('td').find('input').prop("checked", true);
                    form.render(); 
                }else{
                $(data.elem).parent().siblings('td').find('input').prop("checked", false);
                    form.render();  
                }
            });
          
          
        });
        
        function addTable(){
            var trNodes = $("#demo")[0].getElementsByTagName('tr');
            var count = trNodes.length+1;
            
            var tr= '<tr>'+
                        '<td><input type="text" name="'+count+'_payment_period" class="layui-input" value=""></td>' +
                        '<td><input type="text" name="'+count+'_first_rate" class="layui-input" value=""></td>' +
                        '<td><input type="text" name="'+count+'_second_year_rate" class="layui-input" value="">' +
                        '<td><input type="text" name="'+count+'_third_year_rate" class="layui-input" value=""></td>' +
                        '<td><input type="text" name="'+count+'_fourth_year_rate" class="layui-input" value=" "></td>' +
                        '<td><input type="text" name="'+count+'_fifth_year_rate" class="layui-input" value=""></td>' +
                    '</tr>';
            $("#demo").append(tr);
            // form.render();

        }
    </script>
    
  </body>

</html><?php /**PATH D:\wwwroot\pengli\resources\views/product/commission.blade.php ENDPATH**/ ?>